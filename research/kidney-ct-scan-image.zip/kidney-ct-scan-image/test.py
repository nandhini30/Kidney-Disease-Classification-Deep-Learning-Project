import os
import random

# Path to your folder containing images
folder_path = "/home/nandhini/Downloads/kidney-ct-scan-image/CT-KIDNEY-DATASET-Normal-Cyst-Tumor-Stone/Tumor"

# Get a list of all image files in the folder
all_images = [file for file in os.listdir(folder_path) if file.endswith(('.png', '.jpg', '.jpeg', '.gif'))]

# Randomly select 225 images
selected_images = random.sample(all_images, 225)

# Get the set of images to delete (all images - selected images)
images_to_delete = set(all_images) - set(selected_images)

# Delete the unselected images
for image in images_to_delete:
    image_path = os.path.join(folder_path, image)
    os.remove(image_path)
    print(f"Deleted {image}")

print(f"225 images are kept, and the rest have been deleted.")

